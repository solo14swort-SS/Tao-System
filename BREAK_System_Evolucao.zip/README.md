# BREAK System — Evolução

## Conteúdo
- `index.html`: versão para abrir/testar no navegador.
- `www/index.html`: versão usada pelo Capacitor.
- `package.json` e `capacitor.config.json`: configuração inicial para gerar APK com Capacitor.

## Criar o projeto Android
1. Extraia este ZIP.
2. Instale Node.js e Android Studio no computador.
3. Abra um terminal dentro desta pasta.
4. Execute `npm install`.
5. Execute `npx cap add android`.
6. Execute `npx cap sync android`.
7. Execute `npx cap open android` e gere o APK pelo Android Studio.

Se a pasta `android` já existir, não execute novamente `npx cap add android`; use `npx cap sync android`.

## Observações
- O sistema gera 1.000 cartas aleatórias por ciclo da loja; as cartas possuem raridade, nome, descrição, atributos e custo em Tāo.
- O armazenamento comporta até 500 cartas. Usar uma carta aplica seus pontos aos atributos e remove a carta do armazenamento; também é possível removê-la sem aplicar os pontos.
- Os dados são salvos localmente no navegador/app. Use Exportar para criar um backup.
- A música selecionada é carregada do dispositivo e precisa ser selecionada novamente após fechar/reabrir o app.
- A renovação da loja ocorre automaticamente após um intervalo aleatório entre 25 e 90 minutos. O botão Renovar agora permite renovar manualmente.
